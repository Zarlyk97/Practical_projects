import 'package:exemple_dart/screen.dart';

void main() {
  Screen calculatorScreen = Screen();
  calculatorScreen.queryNumbersAndOperation();
}
